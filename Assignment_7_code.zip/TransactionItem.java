public interface TransactionItem {
    String getTitle();

    double getCharge();

    int getFrequentPoints();
}