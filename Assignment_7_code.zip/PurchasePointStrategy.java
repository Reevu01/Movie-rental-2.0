public interface PurchasePointStrategy {
    int getPoints();
}