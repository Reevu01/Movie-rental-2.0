public interface RenterPointStrategy {
    int getPoints(int daysRented);
}