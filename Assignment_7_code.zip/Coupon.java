public interface Coupon {

    double applyDiscount(double amount);
}
