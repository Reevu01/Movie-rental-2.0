public interface RentalPriceStrategy {
    double getCharge(int daysRented);
}
