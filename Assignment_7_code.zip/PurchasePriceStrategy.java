public interface PurchasePriceStrategy {
    double getCharge();

    int getFrequentPurchaserPoints();
}