public class FreePurchasePrice extends PurchasePrice {
    public FreePurchasePrice() {
        super(0.0, 0); // 0 price, 0 points
    }
}